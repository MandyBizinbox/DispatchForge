<?php
include 'includes/header.php';
include 'includes/sidebar.php';
?>

<main>
    <h2>Dashboard</h2>
    <p>Welcome to DispatchForge! Use the navigation menu to manage products, orders, users, and settings.</p>
</main>

<?php include 'includes/footer.php'; ?>
