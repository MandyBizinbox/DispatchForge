<footer>
    <p>&copy; 2024 DispatchForge. All rights reserved.</p>
</footer>
</body>
</html>
