<?php
include '../includes/header.php';
include '../includes/sidebar.php';
?>

<main>
    <h2>Report Management</h2>
    <a href="create_report.php">Add New Report</a>
    <!-- Display products in a table -->
</main>

<?php include '../includes/footer.php'; ?>
